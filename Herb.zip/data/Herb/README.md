###### **中药数据集**
format: symptom id set \t herb set
<br>_**组成**_
<br>size：
<br>train_id.txt: 21755
<br>valid_id.txt: 1162
<br>test_id.txt: 3443
<br> meta data id max size:
<br>herb: 753
<br>symptom: 360